/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

#ifdef NDEBUG
#include "hermes_sandbox_impl_opt_compiled_3.c"
#else
#include "hermes_sandbox_impl_dbg_compiled_3.c"
#endif
