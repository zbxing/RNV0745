delete x ** y
