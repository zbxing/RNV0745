({a}) => { "use strict" }
