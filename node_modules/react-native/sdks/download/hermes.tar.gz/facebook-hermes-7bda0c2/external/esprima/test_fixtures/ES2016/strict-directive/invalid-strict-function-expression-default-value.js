(function(a = 1){ "use strict"; })
