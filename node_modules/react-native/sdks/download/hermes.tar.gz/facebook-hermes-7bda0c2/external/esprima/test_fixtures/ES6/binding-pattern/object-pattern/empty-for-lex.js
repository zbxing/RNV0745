for (let {} in 0);
