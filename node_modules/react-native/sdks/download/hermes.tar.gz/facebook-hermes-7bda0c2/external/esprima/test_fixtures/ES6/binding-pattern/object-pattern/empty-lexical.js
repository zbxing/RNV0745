let {} = 0
