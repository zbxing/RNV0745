for (var {x, y} in z);
