class X { set f(...y) {} }
